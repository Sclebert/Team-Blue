The source code for our app that we created using Microsoft Power Apps is attached, however, I would highly recommend 
evaluating the implementation by actually using the app. I have provided the link below. In order to use the app
you will have to accept access to a Google Sheet that should have been shared with you. The Google Sheet is called "Calendar PA test".

https://apps.powerapps.com/play/468c4c1f-1cc4-4a18-8a7e-d723905d5ec9?tenantId=2d4dad3f-50ae-47d9-83a0-9ae2b1f466f8